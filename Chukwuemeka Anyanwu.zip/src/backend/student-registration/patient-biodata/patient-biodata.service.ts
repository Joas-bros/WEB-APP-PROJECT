import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreatePatientBiodataDto } from './dto/create-patient-biodata.dto';
import { UpdatePatientBiodataDto } from './dto/update-patient-biodata.dto';
import { PatientBiodata } from './entities/patient-biodata.entity';
@Injectable()
export class PatientBiodataService {
constructor(
//inject user repository for use here in UsersService as if it is part of the class
@InjectRepository(PatientBiodata)
private PatientBiodataRepository: Repository<PatientBiodata>
){}
async create(createPatientBiodataDto: CreatePatientBiodataDto) {
const newPatientBiodata: PatientBiodata = this.PatientBiodataRepository.create(createPatientBiodataDto)
return this.PatientBiodataRepository.save(newPatientBiodata);
//return 'This action adds a new user';
}
async findAll() {
//return `This action returns all users`;
return await this.PatientBiodataRepository.find();
}
async findOne(id: number) {
  //return `This action returns a #${id} user`;
  return await this.PatientBiodataRepository.findOne({
  where: {
  id // same as id:id
  }
  });
  }
  async update(id: number, updatePatientBiodataDto: UpdatePatientBiodataDto) {
  //return `This action updates a #${id} user`;
  return await this.PatientBiodataRepository.update(id, updatePatientBiodataDto);
  }
  async remove(id: number) {
  //return `This action removes a #${id} user`;
  return await this.PatientBiodataRepository.delete(id);
  }
  }
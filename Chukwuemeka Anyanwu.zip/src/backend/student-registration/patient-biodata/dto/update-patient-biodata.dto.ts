import { PartialType } from '@nestjs/mapped-types';
import { CreatePatientBiodataDto } from './create-patient-biodata.dto';

export class UpdatePatientBiodataDto extends PartialType(CreatePatientBiodataDto) {}

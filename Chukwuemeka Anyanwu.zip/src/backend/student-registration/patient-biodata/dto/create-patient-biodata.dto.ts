export class CreatePatientBiodataDto {
    
    readonly id: number;
    readonly firstname: string;
    readonly middlename: string;
    readonly lastname: string;
    readonly dateOfBirth: Date;
    readonly homeaddress: string
    readonly dateOfRegistration: boolean;
    readonly matriculationNumber: boolean;
    

}

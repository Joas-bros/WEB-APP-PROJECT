import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { PatientBiodataService } from './patient-biodata.service';
import { CreatePatientBiodataDto } from './dto/create-patient-biodata.dto';
import { UpdatePatientBiodataDto } from './dto/update-patient-biodata.dto';

@Controller('patient-biodata')
export class PatientBiodataController {
  constructor(private readonly patientBiodataService: PatientBiodataService) {}

  @Post()
  create(@Body() createPatientBiodatumDto: CreatePatientBiodataDto) {
    return this.patientBiodataService.create(createPatientBiodatumDto);
  }

  @Get()
  findAll() {
    return this.patientBiodataService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.patientBiodataService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updatePatientBiodatumDto: UpdatePatientBiodataDto) {
    return this.patientBiodataService.update(+id, updatePatientBiodatumDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.patientBiodataService.remove(+id);
  }
}

import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PatientBiodataController } from './patient-biodata.controller';
import { PatientBiodataService } from './patient-biodata.service';
import { PatientBiodata } from './entities/patient-biodata.entity';
@Module({
imports: [TypeOrmModule.forFeature([PatientBiodata])],
controllers: [PatientBiodataController],
providers: [PatientBiodataService],
})
export class PatientBiodataModule {}
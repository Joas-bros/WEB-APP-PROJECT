import { Module } from '@nestjs/common';
import { PatientBiodataModule } from './patient-biodata/patient-biodata.module';
import { ClinicalRecordModule } from './clinical-record/clinical-record.module';

@Module({
  imports: [PatientBiodataModule, ClinicalRecordModule]
})
export class StudentRegistrationModule {}

import React, { useState } from 'react';
import axios from 'axios';



const PatientRecords = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setSurname] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [homeAddress, setHomeAddress] = useState('');
  const [dateOfRegistration, setDateOfRegistration] = useState('');
  const [matriculationNumber, setMatriculationNumber] = useState('');

  const handleFirstNameChange = (event) => {
    setFirstName(event.target.value);
  };
  const handleSurnameChange = (event) => {
    setSurname(event.target.value);
  };
  const handleMiddleNameChange = (event) => {
    setMiddleName(event.target.value);
  };
  const handleDateOfBirthChange = (event) => {
    setDateOfBirth(event.target.value);
  };
  const handleHomeAddressChange = (event) => {
    setHomeAddress(event.target.value);
  };
  const handleDateOfRegistrationChange = (event) => {
    setDateOfRegistration(event.target.value);
  };
  const handleMatriculationNumberChange = (event) => {
    setMatriculationNumber(event.target.value);
  };

  const postData = () => {
    axios.post('http://localhost:4000/patient-biodata', {
      firstName,
      middleName,
      lastName,
      dateOfBirth,
      homeAddress,
      dateOfRegistration,
    });
  };


  return (
    <div className="create-form">
      <h1>Toothfixers</h1>
      <label style={{ color: 'white' }}>First Name</label>
      <p>
        <input
          type="text"
          placeholder="Please enter your First Name..."
          onChange={handleFirstNameChange}
          style={{
            width: '400px',
            height: '25px',
            border: '0px',
            borderRadius: '10px',
            backgroundColor: '#f5f5f5',
          }}
        />
      </p>
      <label style={{ color: 'white' }}>Surname</label>
      <p>
        <input
          type="text"
          placeholder="Enter your Surname..."
          onChange={handleSurnameChange}
          style={{
            width: '400px',
            height: '25px',
            border: '0px',
            borderRadius: '10px',
            backgroundColor: '#f5f5f5',
          }}
        />
      </p>
      <label style={{ color: 'white' }}>Middle Name</label>
      <p>
        <input
          type="text"
          placeholder="Enter your Middle Name..."
          onChange={handleMiddleNameChange}
          style={{
            width: '400px',
            height: '25px',
            border: '0px',
            borderRadius: '10px',
            backgroundColor: '#f5f5f5',
          }}
        />
      </p>
      <label style={{ color: 'white' }}>Date of Birth</label>
      <p>
        <input
          type="date"
          placeholder="Enter your Date of Birth..."
          onChange={handleDateOfBirthChange}
          style={{
            width: '400px',
            height: '25px',
            border: '0px',
            borderRadius: '10px',
            backgroundColor: '#f5f5f5',
          }}
        />
      </p>
      <label style={{ color: 'white' }}>Home Address</label>
      <p>
        <input
          type="text"
          placeholder="Enter your Home Address..."
          onChange={handleHomeAddressChange}
          style={{
            width: '400px',
            height: '25px',
            border: '0px',
            borderRadius: '10px',
            backgroundColor: '#f5f5f5',
          }}
        />
      </p>
      <label style={{ color: 'white' }}>Date of Registration</label>
      <p>
        <input
          type="date"
          placeholder="Enter your Date of Registration..."
          onChange={handleDateOfRegistrationChange}
          style={{
            width: '400px',
            height: '25px',
            border: '0px',
            borderRadius: '10px',
            backgroundColor: '#f5f5f5',
          }}
        />
      </p>
      <label style={{ color: 'white' }}>Matriculation Number</label>
      <p>
        <input
          type="number"
          placeholder="Enter your Matriculation Number..."
          onChange={handleMatriculationNumberChange}
          style={{
            width: '400px',
            height: '25px',
            border: '0px',
            borderRadius: '10px',
            backgroundColor: '#f5f5f5',
          }}
        />
      </p>
      <button
        onClick={postData}
        type="submit"
        style={{
          width: '400px',
          height: '23px',
          border: '0px',
          borderRadius: '10px',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#708090',
        }}
      >
        Submit
      </button>
    </div>
  );
};

export default PatientRecords;

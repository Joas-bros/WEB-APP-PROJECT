// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const PatientRecords = () => {
//   const [patients, setPatients] = useState([]);

//   useEffect(() => {
//     fetchData();
//   }, []);

//   const fetchData = async () => {
//     try {
//       const response = await axios.get('http://localhost:4000/patient-biodata');
//       setPatients(response.data);
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   const deletePatient = async (id) => {
//     try {
//       await axios.delete(`http://localhost:4000/patient-biodata/${id}`);
//       fetchData();
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   return (
//     <div>
//       <h1>Patient Records</h1>
//       <table>
//         <thead>
//           <tr>
//             <th>First Name</th>
//             <th>Last Name</th>
//             <th>Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {patients.map((patient) => (
//             <tr key={patient.id}>
//               <td>{patient.firstName}</td>
//               <td>{patient.lastName}</td>
//               <td>
//                 <button onClick={() => deletePatient(patient.id)}>Delete</button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default PatientRecords;

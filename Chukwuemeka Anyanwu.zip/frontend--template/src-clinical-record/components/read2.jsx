// import axios from "axios";
// import React, {useState} from "react";

// const baseURL = "http://localhost:4000/patient-biodata";

// export default function PatientRecordread() {
//   const [patient, setPatients] = React.useState([]);
//   const [post, setPost] = useState('');
  
  
//   React.useEffect(() => {
//     axios.get(baseURL).then((response) => {
//       setPost(response.data);
//       console.log(response.data)
    
//     });
//   }, []);


//   if (!post) return null;

//   return (
//     <div className="table-container">
//       <table>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>First Name</th>
//             <th>Last Name</th>
//             <th>Date of Birth</th>
//             {/* Add more table headers for other patient record fields */}
//           </tr>
//         </thead>
//         <tbody>
//           {post.map(patient => (
//             <tr key={patient.id}>
//               <td>{patient.firstName}</td>
//               <td>{patient.lastName}</td>
//               <td>{patient.dateOfBirth}</td>
//               {/* Add more table cells for other patient record fields */}
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
    
//   );
// }
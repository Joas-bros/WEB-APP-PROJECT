import logo from './logo.svg';
import './App.css';
import PatientRecords from './components/create';
//import PatientRecordsRead from './components/read';
import PatientRecordread from './components/read2'
import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

const App = () => {
return (
  <div>
    <h1>Welcome to ToothFixers</h1>
    <p>
      At ToothFixers, we are dedicated to providing high-quality dental care and restoring smiles. Our team of experienced dentists and dental specialists is committed to delivering personalized treatment options tailored to your unique dental needs.
    </p>
    <h2>Our Services</h2>
    <p>
      We offer a comprehensive range of dental services, including:
    </p>
    <ul>
      <li>General Dentistry: Regular check-ups, cleanings, and preventive care.</li>
      <li>Cosmetic Dentistry: Enhancing your smile with teeth whitening, veneers, and more.</li>
      <li>Restorative Dentistry: Repairing damaged teeth with fillings, crowns, and bridges.</li>
      <li>Orthodontics: Straightening teeth and correcting bite issues with braces or aligners.</li>
      <li>Oral Surgery: Extracting impacted teeth and performing dental implants.</li>
      <li>Periodontics: Treating gum diseases and maintaining gum health.</li>
      <li>Endodontics: Performing root canal treatments to save severely damaged teeth.</li>
    </ul>
    <h2>Why Choose ToothFixers?</h2>
    <p>
      We understand that visiting the dentist can be a daunting experience for some, which is why we prioritize your comfort and well-being. When you choose ToothFixers, you can expect:
    </p>
    <ul>
      <li>Expert Care: Our skilled dental professionals stay up-to-date with the latest techniques and technologies to provide you with the best treatment.</li>
      <li>Compassionate Approach: We listen to your concerns, explain procedures in detail, and ensure you feel at ease throughout your dental journey.</li>
      <li>State-of-the-Art Facilities: Our modern dental clinic is equipped with advanced equipment to deliver efficient and effective dental care.</li>
      <li>Customized Treatment Plans: We create personalized treatment plans tailored to your specific oral health goals and budget.</li>
      <li>Patient Education: We believe in empowering our patients with knowledge, offering guidance on oral hygiene practices and preventive care.</li>
      <li>Flexible Appointments: We strive to accommodate your schedule and offer convenient appointment times.</li>
    </ul>
    <h2>Contact Us</h2>
    <p>
      Ready to take the first step towards a healthier smile? Contact ToothFixers today to schedule an appointment or learn more about our services.
    </p>
    <nav>
    <ul>
      <li>
        <Link to="/">create</Link>
      </li>
      <li>
        <Link to="/delete">delete</Link>
      </li>
      <li>
        <Link to="/read2">Read</Link>
      </li>
      <li>
        <Link to="/update">Update</Link>
      </li>
    </ul>
  </nav>
    <p>
      Phone: (123) 456-7890<br />
      Email: info@toothfixers.com<br />
      Address: 123 Main Street, Cityville, State, ZIP
    </p>
  </div>
);
}



function App() {
  return (
    <div className="App">
      <Router>
      <Switch>
        <Route exact path="/" component={Home} />
        <Route path="/create" component={PatientRecords} />
        <Route path="/read" component={PatientRecordread} />
        <Route path="/delete" component={deletePatient} />
      </Switch>
    </Router>
      
      {/* <IntroPage/> */}
      {/*<PatientRecordsRead/>*/}
 {/*<PatientRecords/>*/}
 {/*<PatientRecordread/>*/}
    </div>
  );
}

export default App;
